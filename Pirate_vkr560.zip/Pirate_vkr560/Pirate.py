class CoordinateRow:

    def __init__(self):
        pass

    def interlace(self, list0, list1):
        # creating a function to interlace the first two elements in the list.
        output = []
        smallest_list = min(len(list0), len(list1))

        for i in range(smallest_list):
            output.append(list0[i])
            output.append(list1[i])

        # interlacing the first two elements in the list
        output.extend(list0[smallest_list:len(list0)])
        output.extend(list1[smallest_list:len(list1)])

        return output

    def interlace_all_list(self, big_list):
        # interlacing all elements in the list
        calling_class = CoordinateRow()
        output = big_list[0]

        for i in range(1, len(big_list)):
            output = calling_class.interlace(output, big_list[i])
            # Calling Interlace function

        return output


class Coordinate:  # creating new class to calculate the coordinates

    def __init__(self):
        pass

    def adding_coordinates (self, lines):
        calling_class = CoordinateRow()  # we are initialising the class
        int_file = []

        for i in calling_class.interlace_all_list(lines):
            int_file.append(list(map(lambda x: int(x), i.split(','))))
            # converting the elements in the list into integers and splitting them.

        return int_file
        # returning the list.

    def integer_files(self, final_result):
        calling_class = Coordinate() # we are calling the class coordinate
        final = []

        for i in calling_class.adding_coordinates(final_result):
            final.append([i[0] + 1, i[1]])
            # Adding the coordinates [1,0] to the x and y positions.

        [print(row) for row in final]



def splitting_file(name):
    for i in range(len(name)):
        name[i] = name[i].split(' ')

    return name


file_name = input("Enter name of file: ")
chosen_name = splitting_file(open(file_name).read().split('='))

final_coordinates = Coordinate()
print(final_coordinates.integer_files(chosen_name))
